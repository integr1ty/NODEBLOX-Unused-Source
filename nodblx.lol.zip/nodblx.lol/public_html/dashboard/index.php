<?php include("header.php"); ?>
<center>
<img alt="Image" src="https://media.discordapp.net/attachments/1208275098738364488/1236174310893162630/placeholder.png?ex=66370c8a&amp;is=6635bb0a&amp;hm=6615dca569b5878735fc408a18d6fb39e46c4f04dc03fb899b6cc853414e7c5c&amp;=&amp;format=webp&amp;quality=lossless&amp;width=225&amp;height=275" style="width: 180px; height: 220px;">
<center>
Hello Guest 0001
<center>
<img alt="Image" src="https://media.discordapp.net/attachments/1208275098738364488/1236178877110292593/186.png?ex=663710cb&amp;is=6635bf4b&amp;hm=71c0036925464f1e2aed61287f443dfd4291a7fbc287822d4d7612291f68acc3&amp;=&amp;format=webp&amp;quality=lossless&amp;width=525&amp;height=287" style="width: 420px; height: 230px;">
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Play Game Button</title>
</head>
<body>
<center>
<button onclick="window.location.href='/client/'">Play Game!</button>

</body>
</html>
  
